# One possible way to carve up Fahim's ROC data files
# by Giovanni July 27, 2011

#===============================================================================
def loadCategories (filename):
#===============================================================================
    """Load a category file and return a list of lists.
       The category file has one class of exploits per line and uses :: between the items
        e.g.
            5 :: Remote Framebuffer VNC Exploits :: 5.1.1 :: 5.1.2 :: 5.2 :: 5.3
           29 :: POP3 Login Attempt
        
        Each line is turned into a list:      
          - The first item is the value to return if this class matches (e.g. 14 for 14.1.1, 14.1.2 ...)
          - the second item is the values to be tested (those like the 14.1.1 or 18 above)
          - the third is the description of this class of attack/payload ...
        If there is only one item to test (like the 29 above, the first and second items are the same:
        The above pair of lines should return:
         [ [ '5', ['5.1.1', '5.1.2', '5.2', '5.3'], " Remote Framebuffer VNC Exploits"], 
           [ '29',['29'], 'POP3 Login Attempt'] 
         ]
        IMPORTANT: 
            The items in the list are all strings, even if they look like numbers. This means that a 
            category file like this is fine (even though it makes no sense):
            
              webstuff    :: Web browswer related stuff :: http :: https :: GET :: POST
              fileTranfer :: File transfer related      :: ftp :: scp :: rcp
            
            As it's written, the capitalisation must match when testing the list items    
    """
    categories = []
    topLevelCategories = []    # These are the result categories like 14, 15, 18, 29.1 is 
    f = open(filename, "r");
    for line in f:
        if line == "": continue        # ignore blank lines
        fields = line.split("::")
        fields = [ item.strip() for item in fields]     # trim leading and trailing spaces
        fieldCount = len(fields)
        assert fieldCount >= 2, "Line has less than two fields: " + line
        description = fields[1]
        if fieldCount == 2:           # No subclasses, so if first value matches return it   
          returnValue = fields[0]
          testValues    = fields[0:1]  # Make sure the test values are a list, even if only a single item
        else:
          returnValue = fields[0]
          testValues    = fields[2:]  # All fields after the description are test values
        testVector = [returnValue, testValues, description]   
        # print testVector
        categories.append(testVector)
        topLevelCategories.append(returnValue)
    return categories, topLevelCategories
        
        
#===============================================================================
def dumpCategories(categoryList, topLevelCategories):
#===============================================================================
    """ Display the list of categories for easy reading and checking"""
    print "Dump of the parsed Category tests"    
    for category in categoryList:
        print "\nDescription: ", category[2]
        print "    ", category[1] , "===>>> ", category[0]
    print "\nTop Level (result class) categories:"
    print "   ", topLevelCategories

#===============================================================================
def categorisePayload(header, categories):
#===============================================================================
    " find what a header (e.g. 14.1.2), matches (i.e. 14) and return it "
    for vector in categories:
        if header in vector[1]: 
           return vector[0]
    return None      # This should never happen, it's checked later 

#===============================================================================
def classifyAttack(line, categories, lineNo):
#===============================================================================
    """ 
    For the given line from the data file, which is of the form: 
       
      14.1.1-f6e5e49ee210d52a2.fuzz 18-05568905b723efc.fuzz 0.875
    
    split it into the the components "14.1.1",  "18", and "0.875", and then see if 
    the first two are in the same class (after the "14.1.1" has been recognised as
    belonging to the "14" class.
    
    IMPORTANT: This routine assumes the part that should match is terminated with a "-"
    """
    
    part1, part2, value = line.split()           # Split the three parts of the line
    part1Class, part1Details = part1.split("-")  # split the first and second headers at the "-" to extract class
    part2Class, part2Details = part2.split("-")
    category1 = categorisePayload(part1Class, categories)           # Classify the header -> return 14 for 14.1, 14.1.1, 14.1.2
    category2 = categorisePayload(part2Class, categories)
    # Make sure both headers are recognised
    assert category1 is not None, "Line #" + str(lineNo) +" - Can't find " + category1 + " in " + line
    assert category1 is not None, "Line #" + str(lineNo) + " - Can't find " + category1 + " in " + line
    sameCategories = (category1 == category2)

    print "Line ",lineNo, ": ", line, " >>>> ", category1, category2, str(sameCategories).upper()

    # NOW DO SOMETHING :-)
    if sameCategories:                   # Increment Correct classification count
        categoryMatches[category1] = categoryMatches[category1] + 1;
        categoryMatches[category2] = categoryMatches[category2] + 1;
        
    categoryCount[category1] = categoryCount[category1] +1 ;                  # Total Count  
    categoryCount[category2] = categoryCount[category2] +1;
    return sameCategories
    
#===============================================================================
def resetMatchCounts(topLevelCategories):
#===============================================================================
    """
    Reset two arrays that maintain the counts of what matched and the total 
    number of tests for each category to zero. Actually they're dictionaries
    """
    global categoryCount, categoryMatches
    for cat in topLevelCategories:         # Initialise an array of counts
        categoryCount[cat] = 0
        categoryMatches[cat] = 0
    
#===============================================================================
def processResultFile(filename):
#===============================================================================
    lineNo = 0;
    f = open(filename, "r");
    for line in f:
        line = line[:-1]
        lineNo = lineNo+1
        same = classifyAttack(line, categories, lineNo)  # Same Class?

             
    # When finished, display the counts
    print "\nRESULTS:"
    for cat in topLevelCategories:
        print "Class ", cat, ": Totals = ", str(categoryCount[cat]).ljust(6), \
              "  Matching = ", categoryMatches[cat]

#===============================================================================
# Main Program starts here    
categories, topLevelCategories = loadCategories("categories-500.txt")
# print categories
dumpCategories(categories, topLevelCategories)  # can be commented out - diagnostic only - show the categories 

categoryCount   = {}
categoryMatches = {}
resetMatchCounts(topLevelCategories)
processResultFile("test-500-head.txt")
